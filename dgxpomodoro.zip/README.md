# DGX Pomodoro - Basit Pomodoro uygulaması (GitHub Pages için hazır)

Bu proje, GitHub Pages üzerinde kolayca yayımlanabilecek **statik** bir Pomodoro uygulamasıdır.

## İçerik
- `index.html` — Ana sayfa
- `style.css` — Stil dosyası
- `script.js` — Uygulama mantığı (JS)
- `README.md` — Bu dosya

## Nasıl yayımlarım (GitHub Pages)
1. GitHub hesabı oluştur.
2. Yeni bir repository oluştur: örn `dgxpomodoro`
3. Bu dosyaları repository köküne yükle.
4. Repository > Settings > Pages kısmına git.
5. Source kısmından `main` branch ve `/ (root)` seç ve Save'e bas.
6. Birkaç dakika içinde site `https://KULLANICIADI.github.io/dgxpomodoro/` adresinde canlı olur.

## Özellikler
- Çalışma, kısa mola ve uzun mola süreleri ayarlanabilir.
- Belirli sayıda Pomodoro tamamlandığında uzun mola otomatik başlar.
- Sesli bildirim (basit iç ses) ve yerel geçmiş kaydı (LocalStorage) desteği.
- Basit, mobil uyumlu tasarım.

## Lisans
İstersen bu kodu kopyala, değiştir ve kendi projen olarak yayımla. (MIT benzeri serbest kullanım)
