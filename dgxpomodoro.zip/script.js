/* script.js - minimal Pomodoro logic with persistence */
(() => {
  const timeDisplay = document.getElementById('timeDisplay');
  const startBtn = document.getElementById('startBtn');
  const pauseBtn = document.getElementById('pauseBtn');
  const resetBtn = document.getElementById('resetBtn');
  const statusLabel = document.getElementById('statusLabel');
  const completedSpan = document.getElementById('completed');
  const bell = document.getElementById('bell');

  const workInput = document.getElementById('workInput');
  const breakInput = document.getElementById('breakInput');
  const longBreakInput = document.getElementById('longBreakInput');
  const cyclesBeforeLong = document.getElementById('cyclesBeforeLong');

  const soundToggle = document.getElementById('soundToggle');
  const persistToggle = document.getElementById('persistToggle');

  const STORAGE_KEY = 'dgx_pomodoro_state_v1';

  let timer = null;
  let remainingSeconds = 25 * 60;
  let mode = 'work'; // 'work' or 'break' or 'longbreak'
  let running = false;
  let completedCount = 0;

  // Helper: format seconds to MM:SS
  function fmt(s){
    const m = Math.floor(s/60).toString().padStart(2,'0');
    const sec = (s%60).toString().padStart(2,'0');
    return `${m}:${sec}`;
  }

  function loadSettings(){
    // Load inputs from localStorage if persisted
    if(localStorage.getItem(STORAGE_KEY) && persistToggle.checked){
      try{
        const st = JSON.parse(localStorage.getItem(STORAGE_KEY));
        if(st.settings){
          workInput.value = st.settings.work;
          breakInput.value = st.settings.break;
          longBreakInput.value = st.settings.longBreak;
          cyclesBeforeLong.value = st.settings.cyclesBeforeLong;
        }
        if(st.progress){
          completedCount = st.progress.completed || 0;
          completedSpan.textContent = completedCount;
        }
      }catch(e){ console.warn('cannot load state', e) }
    }
  }

  function saveState(){
    if(!persistToggle.checked) return;
    const state = {
      settings: {
        work: Number(workInput.value),
        break: Number(breakInput.value),
        longBreak: Number(longBreakInput.value),
        cyclesBeforeLong: Number(cyclesBeforeLong.value)
      },
      progress: {
        completed: completedCount
      }
    };
    try{
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    }catch(e){}
  }

  function setMode(newMode){
    mode = newMode;
    statusLabel.textContent = mode === 'work' ? 'Çalışma' : (mode === 'break' ? 'Kısa mola' : 'Uzun mola');
    if(mode === 'work'){
      remainingSeconds = Number(workInput.value) * 60;
    } else if(mode === 'break'){
      remainingSeconds = Number(breakInput.value) * 60;
    } else {
      remainingSeconds = Number(longBreakInput.value) * 60;
    }
    updateDisplay();
  }

  function updateDisplay(){
    timeDisplay.textContent = fmt(remainingSeconds);
  }

  function tick(){
    if(remainingSeconds <= 0){
      // End of session
      if(soundToggle.checked){
        try{ bell.play().catch(()=>{}); }catch(e){}
      }
      if(mode === 'work'){
        completedCount++;
        completedSpan.textContent = completedCount;
        // decide next: short or long break
        if(completedCount % Number(cyclesBeforeLong.value) === 0){
          setMode('longbreak');
        } else {
          setMode('break');
        }
      } else {
        setMode('work');
      }
      saveState();
      return; // wait until next tick to countdown new session
    }
    remainingSeconds--;
    updateDisplay();
  }

  function startTimer(){
    if(running) return;
    running = true;
    startBtn.disabled = true;
    pauseBtn.disabled = false;
    statusLabel.textContent = mode === 'work' ? 'Çalışıyor' : 'Mola';
    timer = setInterval(tick, 1000);
  }

  function pauseTimer(){
    if(!running) return;
    running = false;
    startBtn.disabled = false;
    pauseBtn.disabled = true;
    if(timer) clearInterval(timer);
    timer = null;
    statusLabel.textContent = 'Durdu';
    saveState();
  }

  function resetTimer(){
    pauseTimer();
    completedCount = 0;
    completedSpan.textContent = completedCount;
    setMode('work');
    saveState();
  }

  // Event listeners
  startBtn.addEventListener('click', startTimer);
  pauseBtn.addEventListener('click', pauseTimer);
  resetBtn.addEventListener('click', resetTimer);

  // When user changes settings, update display
  [workInput, breakInput, longBreakInput, cyclesBeforeLong].forEach(inp => {
    inp.addEventListener('change', () => {
      // clamp
      if(inp.type === 'number'){
        if(inp.value === '' || isNaN(Number(inp.value))) inp.value = 1;
      }
      // If currently in that mode, update remainingSeconds
      if(mode === 'work' && inp === workInput) remainingSeconds = Number(workInput.value)*60;
      if(mode === 'break' && inp === breakInput) remainingSeconds = Number(breakInput.value)*60;
      if(mode === 'longbreak' && inp === longBreakInput) remainingSeconds = Number(longBreakInput.value)*60;
      updateDisplay();
      saveState();
    });
  });

  persistToggle.addEventListener('change', () => {
    if(!persistToggle.checked) localStorage.removeItem(STORAGE_KEY);
    else saveState();
  });

  // Initialize
  setMode('work');
  loadSettings();
  updateDisplay();
})();
